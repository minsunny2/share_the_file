select user_id,username,account_status,created from dba_users
