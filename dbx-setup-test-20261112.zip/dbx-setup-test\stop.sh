#!/bin/sh

process_stop() {
        if [ ! -f "$1" ]
        then
                echo PID file not found.
                return
        fi

        PIDFILE=$1

        #echo $PIDFILE

        PID=`echo $PIDFILE | sed 's/[^0-9]*//g'`
        if [ -z "$PID" ]
        then
                # dbx-restart.whatap 같은 마커 파일. PID 파일이 아니므로 지우지 않는다.
                echo "Not a PID file: $PIDFILE"
                return
        fi

        rm "$PIDFILE"
        echo PID: $PID
        TR=0

        while [ 1 ]
        do
                if ! kill -0 $PID 2>/dev/null
                then
                        echo ' '===== Agent stopped! =====
                        break
                fi

                TR=`expr $TR + 1`
                if [ "$TR" -ge 16 ]
                then
                        #echo kill -9 $PID
                        printf '9'
                        kill -9 $PID
                elif [ "$TR" -ge 14 ]
                then
                        #echo kill $PID
                        printf 'k'
                        kill $PID
                else
                        printf '*'
                fi

                sleep 1

        done
}

        echo Stop DBX
        PIDFILE=
        for f in dbx-*.whatap
        do
                # 숫자가 없는 이름(dbx-restart.whatap 등)은 PID 파일이 아니다.
                case "$f" in
                        *[0-9]*) PIDFILE=$f; break ;;
                esac
        done
        process_stop "$PIDFILE"
