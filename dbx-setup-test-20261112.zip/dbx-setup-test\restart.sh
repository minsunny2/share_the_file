#!/bin/sh

echo ======================================================= >> restart.out
date >> restart.out
./ps.sh >> restart.out
echo Restart dbx after oom kill. prev pid: $1 >> restart.out
kill -9 $1
rm dbx-*.whatap
sleep 5
./startd.sh
