SELECT df.tablespace_name tbs,df.file_name dat,
round(df.bytes/1024/1024,0) "size",
decode(f.free_bytes,NULL,0,round((df.bytes-f.free_bytes)/1024/1024,0)) used
FROM DBA_DATA_FILES DF,
(SELECT file_id,sum(bytes) free_bytes
FROM dba_free_space
GROUP by file_id) F
WHERE f.file_id(+)=df.file_id
