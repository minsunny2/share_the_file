select * from dba_views where owner not in ('SYS','SYSCAT','SYSGIS')
