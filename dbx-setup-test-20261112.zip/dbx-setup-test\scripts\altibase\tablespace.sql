select * from v$tablespaces
