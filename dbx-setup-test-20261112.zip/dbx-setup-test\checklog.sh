#!/bin/sh

if [ -z "$1" ]
then
        FILENAME=dbx.log
else
        FILENAME=$1/dbx.log
fi

echo $FILENAME

if [ -e $FILENAME ]; then
  FILESIZE=`wc -c < "$FILENAME" | awk '{print $1}'`
  LIMITSIZE=25000000
  MAXFILES=10

  echo filesize: $FILESIZE  limitsize: $LIMITSIZE

  if [ $FILESIZE -gt $LIMITSIZE ]; then

    if [ -e $FILENAME.$MAXFILES ]; then
      rm $FILENAME.$MAXFILES
    fi

    if [ -e $FILENAME.$MAXFILES.gz ]; then
      rm $FILENAME.$MAXFILES.gz
    fi

    ITER=`expr $MAXFILES - 1`
    while [ $ITER -ge 1 ]
    do
      ITERNEXT=`expr $ITER + 1`
      if [ -e $FILENAME.$ITER ]; then
        mv $FILENAME.$ITER $FILENAME.$ITERNEXT
        echo rename $FILENAME.$ITER to $FILENAME.$ITERNEXT
      elif [ -e $FILENAME.$ITER.gz ]; then
        mv $FILENAME.$ITER.gz $FILENAME.$ITERNEXT.gz
        echo rename $FILENAME.$ITER.gz to $FILENAME.$ITERNEXT.gz
      fi
      ITER=`expr $ITER - 1`
    done

    mv $FILENAME $FILENAME.1
    echo mv $FILENAME to $FILENAME.1
  fi
fi

find ./logs/*.log -mtime +60 -exec rm {} \; 2>/dev/null

NOHUPSIZE=`wc -c < "nohup.out" | awk '{print $1}'`
if [ $NOHUPSIZE -gt 10000000 ]; then
  cp nohup.out nohup.out.bak
  cp /dev/null nohup.out
fi
