#!/bin/sh

if [ -e nohup.out ]; then
  FILESIZE=`wc -c < "nohup.out" | awk '{print $1}'`
  LIMITSIZE=25000000
  MAXFILES=10

  echo filesize: $FILESIZE  limitsize: $LIMITSIZE

  if [ $FILESIZE -gt $LIMITSIZE ]; then

    if [ -e nohup.out.$MAXFILES ]; then
      rm nohup.out.$MAXFILES
    fi

    if [ -e nohup.out.$MAXFILES.gz ]; then
      rm nohup.out.$MAXFILES.gz
    fi

    ITER=`expr $MAXFILES - 1`
    while [ $ITER -ge 1 ]
    do
      ITERNEXT=`expr $ITER + 1`
      if [ -e nohup.out.$ITER ]; then
        mv nohup.out.$ITER nohup.out.$ITERNEXT
        echo rename nohup.out.$ITER to nohup.out.$ITERNEXT
      elif [ -e nohup.out.$ITER.gz ]; then
        mv nohup.out.$ITER.gz nohup.out.$ITERNEXT.gz
        echo rename nohup.out.$ITER.gz to nohup.out.$ITERNEXT.gz
      fi
      ITER=`expr $ITER - 1`
    done

    mv nohup.out nohup.out.1
    echo rename nohup.out to nohup.out.1
  fi
fi
