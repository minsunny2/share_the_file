select * from dba_tables
where owner not in ('SYS','SYSGIS','OUTLN')
