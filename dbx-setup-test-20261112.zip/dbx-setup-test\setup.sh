#!/bin/sh

SERVICE_NAME=whatap.agent.setup
config_file="/$PWD/whatap.conf"

echo 
echo "Hello. This is a monitoring configuration file helper. If an error occurs during the process, please take action according to the instructions."
echo 
echo "**Proceed to the next step**"
echo "======================================================"
echo "1.Register WhaTap server information" 
echo "2.Register WhatTap server access key"
echo "3.Register DB server information (ip/port check)"
echo "4.Download jdbc driver"
echo "5.Register a monitoring account(id/pwd check)" 
echo "======================================================"
echo 
echo "if you want to stop setup prees 'q' or 'quit'"

JDBC_DIR=./jdbc

for JDBC in $JDBC_DIR/*.jar
do
    if [ -z "${EXE_LIB_JAR}" ]; then
        EXE_LIB_JAR=$JDBC
    else
        EXE_LIB_JAR=$EXE_LIB_JAR":"$JDBC
    fi
done

echo "JDBC DRIVER = "$EXE_LIB_JAR

EXE_DBX_JAR=`ls $PWD/whatap.agent.dbx*.jar | sort | tail -n 1`
java -cp "$EXE_LIB_JAR:$EXE_DBX_JAR" whatap.setup.AgentConfig

echo
if [ -e "$config_file" ]; then
    echo 
    echo "=====The file exists====="
    echo
    while true;do
	printf "Do you want to start the agent as a daemon? (y/[n])"
	read choice

	choice=${choice:-n}

	case "$choice" in
    	    y|Y|yes|Yes|YES)
		echo	
                echo "The agent was started as a daemon."
		echo "Please check the log [$PWD/logs/whatap.log]."
        	echo "You have completed all steps. Congratulation!!"
		cd "$PWD" && ./startd.sh
		break
            ;;
    	    n|N|no|No|NO)
                echo "You can start the agent with the \"start.sh\" file."
                echo "You can start the agent as a daemon with the \"startd.sh\" file."
                exit 0
            ;;
    	    *)
                echo "Invalid command. Please enter 'y' or 'n'"
            ;;
        esac  
    done
else
    echo "=====The whatap.conf file does not exist. Exit the script====="
fi
