#!/bin/sh
WUID=1002
WUSER=$1
WPASSWORD=$2

EXE_DBX_JAR=`ls $PWD/whatap.agent.dbx*.jar | sort | tail -n 1`

java -cp $EXE_DBX_JAR whatap.dbx.DbUser -update -uid $WUID -user $WUSER -password $WPASSWORD -filename plan.user
