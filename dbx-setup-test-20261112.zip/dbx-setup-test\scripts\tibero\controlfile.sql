select * from v$controlfile
