select * from v$tablespace
