#!/bin/sh

set -- xos-*.whatap
if [ ! -f "$1" ]
then
	echo PID file not found.
	exit 1
fi

PIDFILE=$1

echo $PIDFILE
PID=`echo $PIDFILE | sed 's/[^0-9]*//g'`
echo PID: $PID

ps -p $PID | more
