select * from dba_part_tables
