#!/bin/sh

#./chknohup.sh
nohup $PWD/start.sh -l &
