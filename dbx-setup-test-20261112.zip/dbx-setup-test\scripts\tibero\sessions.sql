select sid,username,sql_et,logon_time,state,wlock_wait,wait_time,pga_used_mem,machine,prog_name from v$session
