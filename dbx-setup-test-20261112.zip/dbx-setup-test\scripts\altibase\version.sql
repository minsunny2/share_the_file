select * from v$version
