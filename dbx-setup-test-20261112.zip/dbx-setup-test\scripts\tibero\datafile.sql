select file_id,file_name,tablespace_name,bytes,autoextensible,increment_by from dba_data_files
