
@echo off
if "%1" == "" (set FILENAME=dbx.log) else (set FILENAME=%1\dbx.log)
echo FILENAME: %FILENAME%

call :filesize %FILENAME%
echo FILESIZE: %SIZE%

if %SIZE% LSS 25000000 goto ENDOFDBXLOG

if exist %FILENAME%.10 del %FILENAME%.10
if exist %FILENAME%.9 ren %FILENAME%.9 %FILENAME%.10
if exist %FILENAME%.8 ren %FILENAME%.8 %FILENAME%.9
if exist %FILENAME%.7 ren %FILENAME%.7 %FILENAME%.8
if exist %FILENAME%.6 ren %FILENAME%.6 %FILENAME%.7
if exist %FILENAME%.5 ren %FILENAME%.5 %FILENAME%.6
if exist %FILENAME%.4 ren %FILENAME%.4 %FILENAME%.5
if exist %FILENAME%.3 ren %FILENAME%.3 %FILENAME%.4
if exist %FILENAME%.2 ren %FILENAME%.2 %FILENAME%.3
if exist %FILENAME%.1 ren %FILENAME%.1 %FILENAME%.2
ren %FILENAME% %FILENAME%.1

:ENDOFDBXLOG

forfiles /P logs /M *.log /D -60 /C "cmd /c del @path"

goto :ENDOFCHECKLOG

:filesize
  set SIZE=%~z1
  exit /b 0

:ENDOFCHECKLOG