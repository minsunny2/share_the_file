set WUID=1001
set WUSER=%1
set WPASSWORD=%2

for /f %%a in ('dir /b/on *.dbx*jar') do set EXE_JAR=%%a

java -cp %EXE_JAR% whatap.dbx.DbUser -update -uid %WUID% -user %WUSER% -password %WPASSWORD% -filename cms.user