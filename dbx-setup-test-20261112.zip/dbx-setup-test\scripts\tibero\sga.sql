select * from v$sga
