select * from v$transaction
