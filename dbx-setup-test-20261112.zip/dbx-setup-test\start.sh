#!/bin/sh

SERVICE_NAME=whatap.agent.dbx
SERVER_HOME=`pwd`

if [ "$1" != "-l" ]
then
    if [ "$1" = "-d" ] || [ "$1" = "" ]
    then
        DBX_PARAM=-d
    else
        DBX_PARAM="-d $1"
    fi
fi

EXE_LIB_JAR=""

JDBC_DIR=./jdbc

for JDBC in $JDBC_DIR/*.jar
do
    if [ -z "${EXE_LIB_JAR}" ]; then
        EXE_LIB_JAR=$JDBC
    else
        EXE_LIB_JAR=$EXE_LIB_JAR":"$JDBC
    fi
done

echo "JDBC DRIVER = "$EXE_LIB_JAR

#JAVA_OPTS="-verbose:gc"
#JAVA_OPTS="$JAVA_OPTS -XX:+UseConcMarkSweepGC"
#JAVA_OPTS="$JAVA_OPTS -XX:+PrintTenuringDistribution"
#JAVA_OPTS="$JAVA_OPTS -XX:+PrintGCDateStamps -XX:+PrintGCDetails"
#JAVA_OPTS="$JAVA_OPTS -Xloggc:./logs/gc.`date +%Y%m%d%H%M`.log"	# HotSpot 전용 옵션 (IBM J9/AIX 미지원). 필요시 J9는 -Xverbosegclog: 사용
#JAVA_OPTS="$JAVA_OPTS -XX:+HeapDumpOnOutOfMemoryError"

if [ ! -d logs ]
then
    echo mkdir logs
    mkdir logs
fi

while [ true ]
do
	EXE_DBX_JAR=`ls $PWD/whatap.agent.dbx*.jar | sort | tail -n 1`

    java -cp "$EXE_LIB_JAR:$EXE_DBX_JAR" -Xms64m -Xmx128m -XX:OnOutOfMemoryError="kill -9 %p" $JAVA_OPTS whatap.dbx.boot.AgentBoot $DBX_PARAM
    RC=$?	# java 종료코드는 다음 명령에서 덮어써지므로 즉시 저장한다.
    if [ $RC -eq 99 ]
    then
        exit 1
    fi
    if [ $RC -ne 77 ]
    then
    	set -- dbx-*.whatap
    	if [ ! -f "$1" ]
    	then
            exit 1
    	fi
    fi
    echo ========================================== >> ./restart.out
    date >> ./restart.out
    echo "dbx agent restarted!" >> ./restart.out
    sleep 5
done;
