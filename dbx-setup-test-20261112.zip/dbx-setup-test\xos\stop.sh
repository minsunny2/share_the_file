#!/bin/sh

set -- xos-*.whatap
if [ ! -f "$1" ]
then
	echo PID file not found.
	exit 1
fi

PIDFILE=$1

echo $PIDFILE
rm "$PIDFILE"
PID=`echo $PIDFILE | sed 's/[^0-9]*//g'`
echo PID: $PID
TR=0

while [ 1 ]
do
	if ! kill -0 $PID 2>/dev/null
	then
		echo ===== Agent stopped! =====
		break
	fi

	TR=`expr $TR + 1`
	if [ "$TR" -ge 15 ]
	then
		echo kill $PID
		kill $PID
	fi

	sleep 1
done
