@echo off
rem Demo: write a resume file so the values are pre-filled (collector, access key, DB). Password is not saved - type it
cd /d "%~dp0.."
set /p KEY=<"%~dp0access_key.txt"
(
echo \#step=3
echo whatap.server.host=127.0.0.1
echo whatap.server.port=16600
echo license=%KEY%
echo dbms=mysql
echo db_ip=127.0.0.1
echo db_port=13306
) > .setup-progress
echo Pre-filled. Run test-setup.bat
