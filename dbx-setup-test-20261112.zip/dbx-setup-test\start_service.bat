@echo off
rem =====================================================================
rem  Windows wrapper that mirrors start.sh's restart loop, used by the
rem  Windows Service registration (NSSM). Behaviour:
rem  - Re-scans the latest dbx jar on every iteration so auto-updates
rem    are picked up.
rem  - Exit code 77: agent self-exit for update -> loop and restart.
rem  - Exit code 99: duplicate-instance detected -> stop loop.
rem  - Other codes: loop while a dbx-*.whatap pid file still exists,
rem    otherwise treat as clean shutdown and exit.
rem
rem  Usage: start_service.bat [config_file] [whatap_name]
rem =====================================================================

rem Guard against accidental direct execution (e.g. double-click).
rem The Windows Service registration passes '--service' as the first arg;
rem when missing, show a notice and exit instead of launching the agent.
if /i not "%~1"=="--service" (
    echo This script is intended to be run by the Windows Service ^(nssm^).
    echo Do not run it directly. To register/manage the service, use:
    echo     install_WindowsService.bat create ^<ServiceName^>
    pause
    exit /b 1
)
rem cd before 'shift': shift also shifts %0, so %~dp0 would no longer
rem point to this script's folder.
cd /d "%~dp0"
shift

setlocal enabledelayedexpansion

set CFG_FILE=%~1
if "%CFG_FILE%"=="" set CFG_FILE=whatap.conf

set NAME_OPT=
if not "%~2"=="" set NAME_OPT=-Dwhatap.name=%~2

if not exist logs mkdir logs

rem -- Java run path --------------------------------------------------
rem  To run with a specific JDK, set JAVA_BIN below to the java.exe path.
rem    e.g.  set "JAVA_BIN=C:\Program Files\Java\jdk1.8.0_xxx\bin\java.exe"
rem  If left empty: uses %JAVA_HOME%\bin\java when JAVA_HOME is set,
rem  otherwise falls back to 'java' on the system PATH.
set "JAVA_BIN="
rem Strip quotes typed into the values (e.g. JAVA_HOME="C:\Program Files\Java\jdk").
rem They are not part of the path and break the quoted paths below.
if defined JAVA_BIN set "JAVA_BIN=%JAVA_BIN:"=%"
if defined JAVA_HOME set "JAVA_HOME=%JAVA_HOME:"=%"
if not defined JAVA_BIN if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "JAVA_BIN=%JAVA_HOME%\bin\java.exe"
if not defined JAVA_BIN set "JAVA_BIN=java"

:loop
rem Rescan jdbc/dbx jars every iteration so jar updates and newly
rem added jdbc drivers are picked up without re-registering the service.
rem
rem Notes:
rem  * Windows 'dir *.jar' also matches *.jar_, *.jar.bak (8.3 short-name
rem    compatibility). We verify with %%~xX so only true .jar files pass.
rem  * For dbx jar selection, alphabetic sort fails on multi-digit
rem    versions (e.g. "2.60.10" sorts BEFORE "2.60.9" lexicographically).
rem    The :pick_jar subroutine extracts the version and zero-pads each
rem    segment to 5 digits so a normal string compare matches numeric
rem    comparison. No PowerShell / external dependency.
set EXE_LIB_JAR=.
for /f %%f in ('dir /b .\jdbc\*.jar 2^>nul') do (
    if /i "%%~xf"==".jar" set EXE_LIB_JAR=!EXE_LIB_JAR!;.\jdbc\%%f
)

set EXE_DBX_JAR=
set BEST_KEY=
for /f "delims=" %%a in ('dir /b *.dbx*.jar 2^>nul') do (
    if /i "%%~xa"==".jar" call :pick_jar "%%a"
)

"!JAVA_BIN!" -Xms64m -Xmx128m -Dwhatap.config=!CFG_FILE! !NAME_OPT! -cp "!EXE_LIB_JAR!;!EXE_DBX_JAR!" whatap.dbx.boot.AgentBoot
set RC=!errorlevel!

echo ========================================== >> .\restart.out
echo %DATE% %TIME% exit=!RC! jar=!EXE_DBX_JAR! >> .\restart.out

if !RC! EQU 99 exit /b 1
rem Delay before a restart (mirrors start.sh's 'sleep 5'); avoids a tight
rem spin when the agent keeps failing to come up. 'timeout' is unusable in a
rem non-interactive service, so use ping on the loopback. '-w 1000' caps each
rem wait at 1s so a host that drops loopback ICMP still delays ~5-6s, not ~24s;
rem if ping is unavailable it simply falls through with no delay. The first
rem launch is never delayed.
if !RC! EQU 77 ( ping -n 6 -w 1000 127.0.0.1 >nul & goto loop )

dir /b dbx-*.whatap >nul 2>&1
if !errorlevel! EQU 0 ( ping -n 6 -w 1000 127.0.0.1 >nul & goto loop )

exit /b 1

rem =====================================================================
rem  :pick_jar  <filename>
rem    Updates BEST_KEY / EXE_DBX_JAR if the given jar is a newer version.
rem    Extracts version from "<anything>.dbx-<VERSION>.jar", splits by
rem    '.', pads each of up to 4 segments to 5 digits, builds a sortable
rem    key string and keeps the lexicographically greatest one.
rem =====================================================================
:pick_jar
set "fname=%~1"
set "rawver="
for /f "tokens=2 delims=-" %%v in ("%fname%") do set "rawver=%%v"
if "%rawver%"=="" goto :eof
set "rawver=%rawver:.jar=%"

set "p1=00000" & set "p2=00000" & set "p3=00000" & set "p4=00000"
for /f "tokens=1-4 delims=." %%i in ("%rawver%.0.0.0") do (
    set "p1=00000%%i"
    set "p2=00000%%j"
    set "p3=00000%%k"
    set "p4=00000%%l"
)
set "p1=%p1:~-5%"
set "p2=%p2:~-5%"
set "p3=%p3:~-5%"
set "p4=%p4:~-5%"
set "key=%p1%.%p2%.%p3%.%p4%"

if "%BEST_KEY%"=="" goto :pick_set
if "%key%" GTR "%BEST_KEY%" goto :pick_set
goto :eof
:pick_set
set "BEST_KEY=%key%"
set "EXE_DBX_JAR=%fname%"
goto :eof
