@echo off
setlocal enabledelayedexpansion
echo.
rem Set Service Name for whatap.agent.xos
SET W_COMMAND="%0"
SET W_SERVICE_SVC_NAME=%2
SET W_DELETE=delete
SET W_CREATE=create
SET F_CHK="true"


rem Command Check
IF [%1]==[%W_CREATE%] GOTO GO_NEXT
IF [%1]==[%W_DELETE%] GOTO GO_NEXT
GOTO GO_USAGE

:GO_NEXT
rem Parameter Check
IF "%2".=="". GOTO GO_EMPTY_SVC_NAME
SET SET_SVC_NAME="-name %W_SERVICE_SVC_NAME%"

:GO_EMPTY_SVC_NAME

rem Mode Check
IF [%1]==[%W_CREATE%] GOTO GO_CREATE
IF [%1]==[%W_DELETE%] GOTO GO_DELETE
GOTO GO_USAGE

rem =================================================================
rem = Delete Start ==================================================
:GO_DELETE
echo # %W_SERVICE_SVC_NAME% Delete Start..

rem Delete Windows Services

whatap.agent.xos.exe -delete "%SET_SVC_NAME%"
#sc delete %W_SERVICE_SVC_NAME%

GOTO FINAL_END
rem = Delete   End ==================================================

rem = Create Start ==================================================
:GO_CREATE
echo # %W_SERVICE_SVC_NAME% Create Start..

whatap.agent.xos.exe -install "%SET_SVC_NAME%"

GOTO FINAL_END
rem = Create   End ==================================================

rem = Usage  Start ==================================================
:GO_USAGE
echo # Usage1 - Register
echo  : %W_COMMAND% %W_CREATE% - Register with Windows Services. (Default RegName WhaTapXOSAgent)
echo  : %W_COMMAND% %W_CREATE% {Windows Service Name} - Register with Windows Services.
echo.
echo # Usage2 - Uninstall
echo  : %W_COMMAND% %W_DELETE% - Uninstall from Windows Services. (Default RegName WhaTapXOSAgent)
echo  : %W_COMMAND% %W_DELETE% {WindowsServices RegName} - Uninstall from Windows Services.
GOTO FINAL_END
rem = Usage    End ==================================================

rem = Final End ==================================================
:FINAL_END
rem = Final End ==================================================