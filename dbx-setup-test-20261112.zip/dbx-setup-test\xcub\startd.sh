#!/bin/sh

EXE_XCUB=`ls $PWD/whatap.agent.xcub* | tail -n 1`
$EXE_XCUB -D
