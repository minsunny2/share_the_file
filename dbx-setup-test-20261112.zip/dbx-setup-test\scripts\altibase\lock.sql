select * from v$lock
