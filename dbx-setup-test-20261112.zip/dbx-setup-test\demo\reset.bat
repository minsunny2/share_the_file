@echo off
rem Demo: back to the initial state (whatap.conf, db.user, resume file, downloaded driver, logs). Keeps .setup-lang
cd /d "%~dp0.."
del /q whatap.conf db.user .setup-progress 2>nul
del /q jdbc\*.jar jdbc\*.bak 2>nul
del /q logs\*.log 2>nul
echo Reset done.
