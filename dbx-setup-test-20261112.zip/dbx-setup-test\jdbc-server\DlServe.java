import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;

import com.sun.net.httpserver.HttpServer;

/** 시험용 드라이버 다운로드 서버 — GET /download/<파일> · 속도 제한 (진행률 막대 확인용) */
public class DlServe {
    public static void main(String[] a) throws Exception {
        final File dir = new File(a[0]);
        int port = Integer.parseInt(a[1]);
        final int bytesPerSec = Integer.parseInt(a[2]);
        HttpServer s = HttpServer.create(new InetSocketAddress(port), 0);
        s.createContext("/download/", ex -> {
            String name = ex.getRequestURI().getPath().substring("/download/".length());
            File f = new File(dir, name);
            System.out.println(new java.util.Date() + " GET " + name + (f.isFile() && !name.contains("/") ? " 200" : " 404"));
            if (name.contains("/") || !f.isFile()) {
                ex.sendResponseHeaders(404, -1);
                ex.close();
                return;
            }
            ex.sendResponseHeaders(200, f.length());
            try (InputStream in = new FileInputStream(f); OutputStream out = ex.getResponseBody()) {
                byte[] b = new byte[bytesPerSec / 10];
                int n;
                while ((n = in.read(b)) > 0) {
                    out.write(b, 0, n);
                    out.flush();
                    Thread.sleep(100);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
        s.start();
        System.out.println("serving " + dir + " on :" + port + " at " + bytesPerSec + " B/s");
    }
}
