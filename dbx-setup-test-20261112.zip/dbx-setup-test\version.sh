#!/bin/sh

EXE_DBX_JAR=`ls $PWD/whatap.agent.dbx*.jar | sort | tail -n 1`


echo `java -cp $EXE_DBX_JAR whatap.Version`
