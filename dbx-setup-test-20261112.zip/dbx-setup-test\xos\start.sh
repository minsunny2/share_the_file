#!/bin/sh

EXE_XOS=`ls $PWD/whatap.agent.xos-* | tail -n 1`
$EXE_XOS $1 $2
