#!/bin/sh

PIDFILE=
for f in dbx-*.whatap
do
	# 숫자가 없는 이름(dbx-restart.whatap 등)은 PID 파일이 아니다.
	case "$f" in
		*[0-9]*) PIDFILE=$f; break ;;
	esac
done

if [ ! -f "$PIDFILE" ]
then
	echo PID file not found.
	exit 1
fi

echo $PIDFILE
PID=`echo $PIDFILE | sed 's/[^0-9]*//g'`
echo PID: $PID

ps -p $PID -o pid,vsz,time,args
