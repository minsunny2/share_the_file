select table_schema, IFNULL(sum((data_length+index_length)),0) AS Byte
from information_schema.tables
group by table_schema;