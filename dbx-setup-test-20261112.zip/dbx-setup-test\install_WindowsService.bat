@echo off
setlocal enabledelayedexpansion
echo.
rem =====================================================================
rem  WhaTap DBX Agent - Windows Service installer (NSSM based)
rem
rem  Usage (same interface as the legacy srvany version):
rem    install_WindowsService.bat create [ServiceName] [ConfFile] [RegName]
rem    install_WindowsService.bat delete [ServiceName]
rem
rem  - Uses nssm.exe instead of the deprecated srvany/instsrv.
rem  - Actual java launch / restart / latest-jar pick-up is done by
rem    start_service.bat (Windows counterpart of start.sh).
rem  - 'create' refuses to overwrite an existing service of the same name.
rem    Delete it first if you want to re-register.
rem  - 'delete' removes a srvany or NSSM registration the same way.
rem  - Start/stop: use services.msc.
rem =====================================================================

SET W_COMMAND="%0"
SET W_SERVICE_SVC_NAME=%2
SET W_SERVICE_CFG_NAME=%~3
SET W_SERVICE_REG_NAME=%~4
SET W_DELETE=delete
SET W_CREATE=create

rem File Check
SET F_CHK="true"
IF NOT EXIST nssm.exe SET F_CHK="false"
IF NOT EXIST start_service.bat SET F_CHK="false"
IF %F_CHK%=="false" GOTO GO_FILECHK

rem Command Check
IF [%1]==[%W_CREATE%] GOTO GO_NEXT
IF [%1]==[%W_DELETE%] GOTO GO_NEXT
GOTO GO_USAGE

:GO_NEXT
IF "%W_SERVICE_SVC_NAME%"=="" SET W_SERVICE_SVC_NAME=WhatapDBXAgent
IF "%W_SERVICE_CFG_NAME%"=="" SET W_SERVICE_CFG_NAME=whatap.conf

IF [%1]==[%W_CREATE%] GOTO GO_CREATE
IF [%1]==[%W_DELETE%] GOTO GO_DELETE
GOTO GO_USAGE

rem =================================================================
rem = Delete (srvany or NSSM) =======================================
:GO_DELETE
echo # %W_SERVICE_SVC_NAME% Delete Start..

sc query %W_SERVICE_SVC_NAME% >nul 2>&1
IF ERRORLEVEL 1 (
    echo # Service "%W_SERVICE_SVC_NAME%" is not registered. Nothing to do.
    GOTO FINAL_END
)

rem Both srvany and NSSM register as standard Windows services, so a plain
rem 'sc stop' + 'sc delete' removes either one.
sc stop %W_SERVICE_SVC_NAME% >nul 2>&1
ping -n 4 127.0.0.1 >nul
sc delete %W_SERVICE_SVC_NAME%
GOTO FINAL_END

rem =================================================================
rem = Create =========================================================
:GO_CREATE
echo # %W_SERVICE_SVC_NAME% / %W_SERVICE_CFG_NAME% Create Start..

rem Refuse to overwrite an existing service. The user must delete it first,
rem so a running service / agent java is never stopped unexpectedly by 'create'.
sc query %W_SERVICE_SVC_NAME% >nul 2>&1
IF NOT ERRORLEVEL 1 (
    echo # Service "%W_SERVICE_SVC_NAME%" already exists.
    echo # Please remove it first, then run 'create' again:
    echo #     %W_COMMAND% delete %W_SERVICE_SVC_NAME%
    GOTO FINAL_END
)

rem Config file existence check
IF NOT EXIST "%W_SERVICE_CFG_NAME%" (
    echo File Not Found : "%W_SERVICE_CFG_NAME%"
    echo.
    GOTO GO_USAGE
)

rem Java check - start_service.bat runs java from JAVA_BIN / JAVA_HOME / PATH.
rem Pass if java is on PATH, OR a valid JAVA_HOME exists; otherwise warn.
SET JAVA_EXE_HOME=
FOR /f %%j IN ("java.exe") DO SET JAVA_EXE_HOME=%%~dp$PATH:j
SET JAVA_OK=
rem Strip quotes typed into JAVA_HOME (e.g. "C:\Program Files\Java\jdk"), same as
rem start_service.bat. Otherwise the check below wrongly passes.
IF DEFINED JAVA_HOME SET "JAVA_HOME=%JAVA_HOME:"=%"
IF NOT "%JAVA_EXE_HOME%"=="" (
    SET JAVA_OK=1
    echo # JAVA_EXE = "%JAVA_EXE_HOME%java.exe" ^(on PATH^)
)
IF NOT DEFINED JAVA_OK IF DEFINED JAVA_HOME IF EXIST "%JAVA_HOME%\bin\java.exe" (
    SET JAVA_OK=1
    echo # JAVA_EXE = "%JAVA_HOME%\bin\java.exe" ^(via JAVA_HOME^)
)
IF NOT DEFINED JAVA_OK GOTO GO_JAVACHK

rem Register via NSSM. start_service.bat receives: %1=conf, %2=name
rem '--service' is a sentinel arg: start_service.bat refuses to run without it,
rem so the user can't accidentally launch the agent by double-clicking it.
IF "%W_SERVICE_REG_NAME%"=="" (
    nssm install %W_SERVICE_SVC_NAME% "%cd%\start_service.bat" --service "%W_SERVICE_CFG_NAME%" >nul 2>&1
) ELSE (
    nssm install %W_SERVICE_SVC_NAME% "%cd%\start_service.bat" --service "%W_SERVICE_CFG_NAME%" "%W_SERVICE_REG_NAME%" >nul 2>&1
)
IF ERRORLEVEL 1 (
    echo # Failed to install service.
    GOTO FINAL_END
)

rem nssm 'set' output is suppressed (it is UTF-16 and noisy on redirect).
rem AppKillProcessTree is unsupported by some nssm builds (e.g. 2.24) and is
rem silently ignored there -- those builds terminate the process tree anyway.
nssm set %W_SERVICE_SVC_NAME% AppDirectory "%cd%" >nul 2>&1
nssm set %W_SERVICE_SVC_NAME% Description "WhaTap DBX Agent" >nul 2>&1
nssm set %W_SERVICE_SVC_NAME% Start SERVICE_AUTO_START >nul 2>&1
nssm set %W_SERVICE_SVC_NAME% AppKillProcessTree 1 >nul 2>&1
nssm set %W_SERVICE_SVC_NAME% AppStopMethodConsole 15000 >nul 2>&1
nssm set %W_SERVICE_SVC_NAME% AppExit Default Exit >nul 2>&1

echo.
echo # Service registered: %W_SERVICE_SVC_NAME%
echo # Start/Stop: use services.msc
echo # Remove   : %W_COMMAND% delete %W_SERVICE_SVC_NAME%
GOTO FINAL_END

rem =================================================================
rem = Usage =========================================================
:GO_USAGE
echo # Usage1 - Register
echo  : %W_COMMAND% %W_CREATE%
echo  : %W_COMMAND% %W_CREATE% {ServiceName}
echo  : %W_COMMAND% %W_CREATE% {ServiceName} {ConfFile}
echo  : %W_COMMAND% %W_CREATE% {ServiceName} {ConfFile} {RegName}
echo.
echo # Usage2 - Uninstall
echo  : %W_COMMAND% %W_DELETE%
echo  : %W_COMMAND% %W_DELETE% {ServiceName}
echo.
echo # Start/stop: use services.msc.
GOTO FINAL_END

rem =================================================================
rem = FileChk =======================================================
:GO_FILECHK
echo # The following files are required in this directory:
echo  - nssm.exe          : NSSM service wrapper. Bundled with the agent.
echo  - start_service.bat : Agent launcher with auto-restart loop. Bundled with the agent.
GOTO FINAL_END

rem =================================================================
rem = JavaChk =======================================================
:GO_JAVACHK
echo # JDK(java.exe) is required to start DBAgent. Provide it in one of:
echo #  - add JDK 1.7/1.8 (OracleJDK/OpenJDK) bin to the system PATH, or
echo #  - set JAVA_HOME so that %%JAVA_HOME%%\bin\java.exe exists, or
echo #  - set JAVA_BIN in start_service.bat to a java.exe path.
GOTO FINAL_END

rem =================================================================
:FINAL_END
endlocal
