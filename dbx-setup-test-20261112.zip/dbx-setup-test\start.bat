@echo off

for /f %%a in ('dir /b/on *.dbx*jar') do set EXE_DBX_JAR=%%a

set DBX_PARAM=
if "%1"=="-l" goto param_end
if "%1"=="-d" goto param_d
if "%1"=="" goto param_d
set DBX_PARAM=-d %1
goto param_end
:param_d  
set DBX_PARAM=-d
:param_end

set EXE_LIB_JAR=.

setlocal enabledelayedexpansion

for /f %%f in ('dir /b .\jdbc\*.jar') do set EXE_LIB_JAR=!EXE_LIB_JAR!;.\jdbc\%%f

java -Xms64m -Xmx128m -cp %EXE_LIB_JAR%;%EXE_DBX_JAR% whatap.dbx.boot.AgentBoot %DBX_PARAM%