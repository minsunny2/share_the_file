@echo off
rem Local test only: download JDBC drivers from local docker dbx-download (127.0.0.1:18080), then run the original setup.bat
rem Demo: fake WhaTap collector on 127.0.0.1:16600 (minimized window) + demo values as placeholders (demo\demo.properties)
rem (setup.bat itself is untouched)
cd /d "%~dp0"
start "fake-collector" /min powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0demo\fake-collector.ps1"
set WHATAP_DOWNLOAD_URL=http://127.0.0.1:18080/download
set WHATAP_SETUP_DEMO=%~dp0demo\demo.properties
call "%~dp0setup.bat"
