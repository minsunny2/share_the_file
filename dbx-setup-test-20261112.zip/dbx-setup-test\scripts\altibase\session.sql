select * from v$session
