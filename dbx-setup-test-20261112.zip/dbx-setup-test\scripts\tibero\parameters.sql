select * from v$parameters
