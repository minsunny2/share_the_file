select * from v$pe_session
