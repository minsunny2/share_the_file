select * from v$instance
