select * from v$database
