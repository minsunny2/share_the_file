# Demo only: fake WhaTap collector on 127.0.0.1:16600 - accepts and closes (setup collector check = OK). Close this window to stop.
$l = New-Object System.Net.Sockets.TcpListener ([System.Net.IPAddress]::Loopback, 16600)
try { $l.Start() } catch { Write-Host "port 16600 already in use - fake collector not started"; Start-Sleep 3; exit }
Write-Host "fake WhaTap collector 127.0.0.1:16600 (demo) - close this window to stop"
while ($true) { $c = $l.AcceptTcpClient(); $c.Close() }
