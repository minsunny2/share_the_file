# Guide to download JDBC
 It provides the download links and setup locations for each JDBC file for DBX agents.
 Download the JDBC driver for the DBMS type to <agent installation directory>/jdbc.

----

## Mysql & MariaDB 
https://downloads.mysql.com/archives/c-j/ 

----

## Postgresql
https://jdbc.postgresql.org/download/

----

## EDB 
https://www.enterprisedb.com/advanced-downloads

----

## Oracle
https://www.oracle.com/database/technologies/appdev/jdbc-downloads.html

----

## MS SQL Server 
https://learn.microsoft.com/ko-kr/sql/connect/jdbc/release-notes-for-the-jdbc-driver?view=sql-server-ver16#previous-releases

----

## CUBRID
https://ftp.cubrid.org/CUBRID_Drivers/JDBC_Driver/?_gl=1*1um18yv*_ga*MTY0NjQ3MDgxNC4xNzA2NTk2MjM5*_ga_5HW0MPKGJF*MTcyNTg3MTE4Mi4yMDIuMS4xNzI1ODcxNDMzLjYwLjAuMA

----

## Guide to download JDBC for tibero and altibase 

 In case of tibero and altibase, the JDBC driver is loacated under <DB installation directory>.
 See the following path and copy the file to <agent installation directory>/jdbc.

## Tibero 
${TB_HOME}/client/lib/jar/tibero<Version>-jdbc.jar


## Altibase 
${ALTIBASE_HOME}/lib/Altibase.jar

