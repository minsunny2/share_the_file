#!/bin/sh

nohup $PWD/start.sh &
