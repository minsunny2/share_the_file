select * from v$memstat
