#!/bin/sh

DBXDIR=`ls -a dbroot`

for dbxdir in $DBXDIR
do
	DBXPATH=dbroot/$dbxdir
	case $dbxdir in
		.*)
			;;
		*)
			if [ -d "$DBXPATH" ]
			then
				echo $DBXPATH
				cd "$DBXPATH"
				./stop.sh
				break
			fi
			;;
	esac
done
