select * from v$process
