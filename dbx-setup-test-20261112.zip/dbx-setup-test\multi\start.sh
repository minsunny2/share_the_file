#!/bin/sh

# 최신 boot jar 선택. Solaris old awk(ERE FS·printf 미지원) 회피 위해 awk 대신 sed+sort 사용.
# sed: "<버전> <원본경로>" 로 줄 앞에 버전 prepend → sort 숫자 다중키로 버전 정렬 → 최신 1줄의 원본경로만 추출.
DBX_BOOT_JAR=`ls $PWD/whatap.agent.dbx.boot*.jar | sed 's|.*boot-\([0-9.]*\)\.jar|\1 &|' | sort -t. -k1,1n -k2,2n -k3,3n -k4,4n | tail -n 1 | sed 's/^[^ ]* //'`

echo $DBX_BOOT_JAR

java -cp $DBX_BOOT_JAR -Xms500m -Xmx1g whatap.boot.App
