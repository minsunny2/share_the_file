@echo off
setlocal enabledelayedexpansion

for /f %%a in ('dir /b/on *.dbx*jar') do set EXE_DBX_JAR=%%a

set SERVICE_NAME=whatap.agent.setup
set "config_file=%CD%\whatap.conf"

echo.
echo "Hello. This is a monitoring configuration file helper. If an error occurs during the process, please take action according to the instructions."
echo.
echo "**Proceed to the next step**"
echo "======================================================"
echo "1. Register WhaTap server information"
echo "2. Register WhatTap server access key"
echo "3. Register DB server information (ip/port check)"
echo "4. Download jdbc driver"
echo "5. Register a monitoring account(id/pwd check)"
echo "======================================================"
echo.
echo "If you want to stop setup, press 'q' or 'quit'"

for %%f in (.\jdbc\*.jar) do (
    if exist %%f (
        set "bakfile=%%~dpnf.jar.bak"
        if exist "!bakfile!" (
	   echo Deleting existing backup file: !bakfile!
            del "!bakfile!"
        )
        echo MYJDBCFILE: %%f
        ren "%%f" "%%~nxf.bak"
    )
)

java -Xms64m -Xmx128m -cp %EXE_DBX_JAR% whatap.setup.AgentConfig

echo.
if exist "%config_file%" (
    echo.
    echo "===== The file exists ====="
    echo.
    set /p "choice=Do you want to start the agent? ([y]/n): "

    if /i "!choice!" == "yes" (
        set "choice=y"
    )
    
    if not defined choice (
	set "choice=y" 
    ) else (
	set "choice=!choice:~-1!"
    )
    
    if /i "!choice!" == "y" (
        echo.
        echo "The agent was started."
        echo "Please check the log [%CD%\logs\whatap.log]."
        echo "You have completed all steps. Congratulations!!"
        cd "%CD%" && start.bat
    ) else (
        echo "You can start the agent with the "start.bat" file."
        exit /b 0
    )
) else (
    echo "===== The whatap.conf file does not exist. Exit the script ====="
)

endlocal
